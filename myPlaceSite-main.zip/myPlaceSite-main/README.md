# Website myPlace Responsive
## O myPlace é um projeto do curso Front-End Specialist da FIAP construido juntamente com o professor Israel Marques Cajai Junior
### <a href="https://felipethiago21.github.io/myPlaceSite/">Clique Aqui para acessar o myPlace</a>
### Linguagens utilizadas: HTML, CSS, JavaScript.
